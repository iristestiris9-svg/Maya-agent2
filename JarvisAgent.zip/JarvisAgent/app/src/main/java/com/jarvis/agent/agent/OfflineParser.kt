package com.jarvis.agent.agent

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date

/** Works without internet / API key. Understands common Hindi, English and Hinglish commands. */
object OfflineParser {
    private fun step(tool: String, vararg a: Pair<String, Any>): JSONObject {
        val args = JSONObject()
        a.forEach { args.put(it.first, it.second) }
        return JSONObject().put("tool", tool).put("args", args)
    }

    private fun plan(reply: String, vararg s: JSONObject): JSONObject {
        val arr = JSONArray()
        s.forEach { arr.put(it) }
        return JSONObject().put("reply", reply).put("steps", arr)
    }

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun strip(t: String, vararg w: String) =
        t.split(Regex("\\s+")).filter { it !in w }.joinToString(" ").trim()

    fun parse(raw: String): JSONObject? {
        val t = raw.lowercase().trim()
        if (t.isEmpty()) return null
        val nums = Regex("\\d+").findAll(t).mapNotNull { it.value.toIntOrNull() }.toList()

        if (has(t, "hello", "namaste", "हेलो", "नमस्ते", "हैलो"))
            return plan("Namaste! Main offline mode me hoon, basic commands kar sakta hoon.")
        if (has(t, "time kya", "kitne baje", "samay", "समय", "टाइम क्या"))
            return plan("Abhi " + SimpleDateFormat("hh:mm a").format(Date()) + " baj rahe hain.")
        if (has(t, "tarikh", "date kya", "तारीख"))
            return plan("Aaj ki date " + SimpleDateFormat("dd MMM yyyy").format(Date()) + " hai.")

        if (has(t, "setting", "सेटिंग") || has(t, "wifi", "wi-fi", "वाईफाई", "bluetooth", "ब्लूटूथ")) {
            val page = when {
                has(t, "wifi", "wi-fi", "वाईफाई") -> "wifi"
                has(t, "bluetooth", "ब्लूटूथ") -> "bluetooth"
                has(t, "display", "brightness", "डिस्प्ले") -> "display"
                has(t, "sound", "साउंड") -> "sound"
                has(t, "battery", "बैटरी") -> "battery"
                has(t, "notification", "नोटिफिकेशन") -> "notifications"
                has(t, "accessibility") -> "accessibility"
                has(t, "location", "लोकेशन") -> "location"
                has(t, "storage", "स्टोरेज") -> "storage"
                has(t, "language", "भाषा") -> "language"
                has(t, "privacy", "प्राइवेसी") -> "privacy"
                has(t, "security", "सिक्योरिटी") -> "security"
                has(t, "developer") -> "developer"
                else -> "main"
            }
            return plan("$page settings khol raha hoon.", step("open_settings", "page" to page))
        }

        if (has(t, "battery", "बैटरी", "charge", "चार्ज", "storage", "स्टोरेज", "network", "नेटवर्क", "device status"))
            return plan("Device status:", step("device_status"))

        if (has(t, "torch", "flashlight", "टॉर्च", "फ्लैशलाइट", "light jala", "light on")) {
            val off = has(t, "off", "band", "बंद", "bujha", "बुझा")
            return plan(if (off) "Torch band." else "Torch chalu.", step("flashlight", "on" to !off))
        }

        if (has(t, "volume", "वॉल्यूम", "awaz", "आवाज")) {
            return if (nums.isNotEmpty()) plan("Volume set.", step("volume", "level" to nums[0].coerceIn(0, 100)))
            else plan("Volume badal raha hoon.", step("volume", "direction" to
                if (has(t, "down", "kam", "कम", "ghata", "घटा", "low")) "down" else "up"))
        }

        if (has(t, "next song", "agla gana", "अगला", "next track")) return plan("Next.", step("media", "action" to "next"))
        if (has(t, "previous", "pichla", "पिछला")) return plan("Previous.", step("media", "action" to "previous"))

        if (has(t, "youtube", "यूट्यूब")) {
            val q = strip(t, "youtube", "यूट्यूब", "pe", "par", "पे", "पर", "search", "karo", "kar", "play", "chalao",
                "dhundo", "kholo", "open", "खोलो", "में", "me", "mein")
            return if (q.isBlank()) plan("YouTube khol raha hoon.", step("open_app", "name" to "youtube"))
            else plan("YouTube par '$q' search kar raha hoon.", step("youtube_search", "query" to q))
        }

        if (has(t, "pause", "resume", "play", "रोको", "चलाओ") && has(t, "gana", "song", "music", "गाना", "संगीत", "media"))
            return plan("Media play/pause.", step("media", "action" to "play_pause"))

        if (has(t, "alarm", "अलार्म")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return plan("Kitne baje ka alarm lagana hai?")
            var h = m.groupValues[1].toInt() % 24
            val min = m.groupValues[2].toIntOrNull() ?: 0
            if (h < 12 && has(t, "pm", "shaam", "शाम", "raat", "रात", "dopahar", "दोपहर")) h += 12
            return plan("Alarm $h:${min.toString().padStart(2, '0')} ke liye set kar raha hoon.",
                step("set_alarm", "hour" to h, "minute" to min, "label" to "Jarvis"))
        }

        if (has(t, "timer", "टाइमर") && nums.isNotEmpty()) {
            val mult = when {
                has(t, "hour", "ghante", "घंटे") -> 3600
                has(t, "sec", "सेकंड") -> 1
                else -> 60
            }
            return plan("Timer shuru.", step("set_timer", "seconds" to nums[0] * mult))
        }

        if (has(t, "screenshot", "स्क्रीनशॉट")) return plan("Screenshot.", step("ui_global", "action" to "screenshot"))
        if (has(t, "recent apps", "recents")) return plan("Recents.", step("ui_global", "action" to "recents"))
        if (has(t, "notification", "नोटिफिकेशन")) return plan("Notifications.", step("ui_global", "action" to "notifications"))
        if (has(t, "go back", "back jao", "peeche", "पीछे", "वापस जाओ")) return plan("Back.", step("ui_global", "action" to "back"))
        if (has(t, "go home", "home jao", "home screen", "होम"))
            return plan("Home.", step("ui_global", "action" to "home"))
        if (has(t, "scroll", "neeche", "नीचे", "upar", "ऊपर"))
            return plan("Scroll.", step("ui_scroll", "direction" to if (has(t, "up", "upar", "ऊपर")) "up" else "down"))

        if (has(t, "camera", "कैमरा")) return plan("Camera khol raha hoon.", step("open_camera"))

        Regex("^(.+?)\\s+(?:ko|को)\\s+(whatsapp|व्हाट्सएप|व्हाट्सऐप|sms|message|मैसेज)\\s*(?:pe|par|पे|पर|me|में)?\\s*(.*)$")
            .find(t)?.let { m ->
                val to = m.groupValues[1].trim()
                val text = strip(m.groupValues[3], "bhejo", "send", "likho", "भेजो", "लिखो", "kar", "do", "de", "dena")
                val wa = m.groupValues[2].let { it.startsWith("w") || it.startsWith("व") }
                return plan("$to ke liye message taiyaar kar raha hoon.",
                    step(if (wa) "draft_whatsapp" else "draft_sms", "to" to to, "text" to text))
            }

        if (has(t, "call", "dial", "कॉल", "phone laga", "फोन लगा")) {
            val num = Regex("\\+?\\d{5,}").find(t)?.value
            val who = num ?: strip(t, "call", "dial", "kar", "karo", "ko", "laga", "lagao", "phone", "कॉल", "करो", "को",
                "please", "mujhe", "मुझे", "लगाओ", "फोन")
            return if (who.isBlank()) plan("Kisko call karna hai?")
            else plan("$who ko dial kar raha hoon.", step("dial", "to" to who))
        }

        if (has(t, "navigate", "directions", "rasta", "रास्ता", "maps", "नक्शा")) {
            val place = strip(t, "navigate", "to", "directions", "rasta", "ka", "ke", "liye", "maps", "batao", "dikhao",
                "me", "में", "रास्ता", "का", "के", "लिए", "बताओ", "दिखाओ", "open", "kholo")
            return plan("Maps khol raha hoon.", step("navigate", "place" to place))
        }

        if (has(t, "search", "google", "dhundo", "ढूंढो", "सर्च")) {
            val q = strip(t, "search", "google", "karo", "kar", "dhundo", "ढूंढो", "सर्च", "करो", "pe", "par", "for", "about")
            if (q.isNotBlank()) return plan("'$q' search kar raha hoon.", step("web_search", "query" to q))
        }

        val name = (Regex("^(?:open|launch|start)\\s+(.+)$").find(t)
            ?: Regex("^(.+?)\\s+(?:khol do|kholo|khol|open karo|open kar do|open|खोल दो|खोलो|खोल|चालू करो|chalu karo)$").find(t))
            ?.groupValues?.get(1)?.trim()
        if (!name.isNullOrBlank()) return plan("$name khol raha hoon.", step("open_app", "name" to name))

        return null
    }
}
