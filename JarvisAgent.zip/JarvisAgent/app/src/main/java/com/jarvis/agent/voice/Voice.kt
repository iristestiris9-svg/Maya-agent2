package com.jarvis.agent.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class Voice(ctx: Context, private val onText: (String) -> Unit) {
    private val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { tts?.language = Locale("hi", "IN") }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
    }

    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        sr.startListening(i)
    }
    fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    fun shutUp() { tts?.stop() }
    fun destroy() { sr.destroy(); tts?.shutdown() }
}
