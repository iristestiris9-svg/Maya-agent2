package com.jarvis.agent

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jarvis.agent.agent.AgentEngine
import com.jarvis.agent.agent.Planner
import com.jarvis.agent.tools.buildRegistry
import com.jarvis.agent.voice.Voice
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val engine = AgentEngine(this, buildRegistry(this), Planner({ prefs.getString("key", "") ?: "" }, { prefs.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash" }))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { JarvisScreen(engine, prefs) } } }
    }
}

@Composable
fun JarvisScreen(engine: AgentEngine, prefs: SharedPreferences) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash") }
    var busy by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var pending by remember { mutableStateOf<Pair<String, CompletableDeferred<Boolean>>?>(null) }
    val voiceRef = remember { mutableStateOf<Voice?>(null) }

    val send: (String) -> Unit = { t ->
        if (t.isNotBlank() && !busy) {
            msgs.add(true to t); busy = true
            scope.launch {
                engine.handle(t, { m ->
                    msgs.add(false to m)
                    if (!m.startsWith("✓") && !m.startsWith("✗")) voiceRef.value?.speak(m)
                }) { q -> val d = CompletableDeferred<Boolean>(); pending = q to d; d.await() }
                busy = false
            }
        }
    }
    val sendState = rememberUpdatedState(send)
    val voice = remember { Voice(ctx) { sendState.value(it) } }
    voiceRef.value = voice
    DisposableEffect(Unit) { onDispose { voice.destroy() } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)) }

    Column(Modifier.fillMaxSize().padding(12.dp).systemBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(key, { key = it; prefs.edit().putString("key", it).apply() }, Modifier.weight(1f),
                label = { Text("Gemini API key (free)") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            Button({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Enable\nControl") }
        }
        OutlinedTextField(model, { model = it; prefs.edit().putString("model", it).apply() }, Modifier.fillMaxWidth(),
            label = { Text("Model name") }, singleLine = true)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            items(msgs) { (mine, t) ->
                Text((if (mine) "You: " else "Jarvis: ") + t, Modifier.padding(vertical = 4.dp),
                    color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Bolo ya likho…") })
            Button({ voice.listen() }) { Text("🎤") }
            Button({ send(input); input = "" }, enabled = !busy) { Text("➤") }
            Button({ engine.stopped = true; voice.shutUp() }) { Text("⏹") }
        }
    }
    pending?.let { (q, d) ->
        AlertDialog(onDismissRequest = { d.complete(false); pending = null },
            title = { Text("Allow this action?") }, text = { Text(q) },
            confirmButton = { TextButton({ d.complete(true); pending = null }) { Text("Yes") } },
            dismissButton = { TextButton({ d.complete(false); pending = null }) { Text("No") } })
    }
}
